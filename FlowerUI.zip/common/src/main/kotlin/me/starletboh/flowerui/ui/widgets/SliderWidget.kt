package me.starletboh.flowerui.ui.widgets

import me.starletboh.flowerui.events.input.InputEvent
import me.starletboh.flowerui.events.input.MouseEvent
import me.starletboh.flowerui.ui.render.RenderContext

class SliderWidget : Widget() {

    var min: Float = 0f
    var max: Float = 1f

    var value: Float = 0f
        set(v) {
            val clamped = v.coerceIn(min, max)
            if (field == clamped) return
            field = clamped
            onChange?.invoke(field)
        }

    var onChange: ((Float) -> Unit)? = null

    private var dragging = false

    private fun normalized(): Float {
        if (max <= min) return 0f
        return (value - min) / (max - min)
    }

    private fun setFromMouse(px: Double) {
        val t = ((px - globalX()) / width).toFloat().coerceIn(0f, 1f)
        value = min + t * (max - min)
    }

    override fun render(ctx: RenderContext) {

        val trackY = globalY() + height / 2f
        val t = normalized()

        val fillW = width * t

        // track
        ctx.scope.drawRect(
            globalX(),
            trackY - 2f,
            width,
            4f,
            ctx.theme.colors.border
        )

        // fill
        ctx.scope.drawRect(
            globalX(),
            trackY - 2f,
            fillW,
            4f,
            ctx.theme.colors.primary
        )

        // knob
        val knobX = globalX() + fillW - 6f
        ctx.scope.drawRect(
            knobX,
            trackY - 6f,
            12f,
            12f,
            0xFFFFFFFF.toInt()
        )

        renderChildren(ctx)
    }

    override fun onEvent(event: InputEvent): Boolean {
        when (event) {

            is MouseEvent.Click -> {
                if (!contains(event.x, event.y)) return false
                dragging = true
                setFromMouse(event.x)
                event.consume()
                return true
            }

            is MouseEvent.Move -> {
                if (!dragging) return false
                setFromMouse(event.x)
                return true
            }

            is MouseEvent.Release -> {
                dragging = false
                return false
            }
        }
        return false
    }
}