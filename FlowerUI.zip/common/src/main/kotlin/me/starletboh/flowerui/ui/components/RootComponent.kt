package me.starletboh.flowerui.ui.components

import me.starletboh.flowerui.events.input.InputEvent
import me.starletboh.flowerui.ui.render.RenderContext

class RootComponent : Component() {
    fun handleInput(event: InputEvent) {
        dispatchEvent(event)
    }
    override fun render(ctx: RenderContext) {
        renderChildren(ctx)
    }
}