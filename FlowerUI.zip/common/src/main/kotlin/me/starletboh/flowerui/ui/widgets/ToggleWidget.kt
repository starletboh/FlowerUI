package me.starletboh.flowerui.ui.widgets

import me.starletboh.flowerui.events.input.InputEvent
import me.starletboh.flowerui.events.input.MouseEvent
import me.starletboh.flowerui.ui.render.RenderContext

class ToggleWidget : Widget() {

    var value: Boolean = false
        set(v) {
            if (field == v) return
            field = v
            onChange?.invoke(field)
        }

    var onChange: ((Boolean) -> Unit)? = null

    var knobRadius: Float = 6f

    override fun render(ctx: RenderContext) {

        val bg = if (value)
            ctx.theme.colors.primary
        else
            ctx.theme.colors.border

        val knobX = if (value)
            globalX() + width - knobRadius * 2 - 2f
        else
            globalX() + 2f

        val cy = globalY() + height / 2f

        ctx.scope.drawRect(globalX(), globalY(), width, height, bg)
        ctx.scope.drawRect(knobX, cy - knobRadius, knobRadius * 2, knobRadius * 2, 0xFFFFFFFF.toInt())
        ctx.scope.drawOutline(globalX(), globalY(), width, height, ctx.theme.colors.border, 1f)

        renderChildren(ctx)
    }

    override fun onEvent(event: InputEvent): Boolean {
        when (event) {
            is MouseEvent.Click -> {
                if (!contains(event.x, event.y)) return false
                value = !value
                event.consume()
                return true
            }
        }
        return false
    }
}