package me.starletboh.flowerui.ui.widgets

import me.starletboh.flowerui.events.input.InputEvent
import me.starletboh.flowerui.events.input.MouseEvent
import me.starletboh.flowerui.ui.render.RenderContext

class DropdownWidget<T> : Widget() {

    var items: List<T> = emptyList()
    var selectedIndex: Int = -1

    var labelProvider: (T) -> String = { it.toString() }

    var isOpen = false

    var onChange: ((T?) -> Unit)? = null

    val selectedItem: T?
        get() = items.getOrNull(selectedIndex)

    override fun render(ctx: RenderContext) {

        ctx.scope.drawRect(globalX(), globalY(), width, height, ctx.theme.colors.surface)
        ctx.scope.drawOutline(globalX(), globalY(), width, height, ctx.theme.colors.border, 1f)

        val label = selectedItem?.let(labelProvider) ?: "Select..."
        ctx.scope.drawText(label, globalX() + 6f, globalY() + height / 2f, ctx.theme.colors.textPrimary, 1f)

        if (isOpen) {
            val itemH = height

            for (i in items.indices) {
                val y = globalY() + height + i * itemH

                ctx.scope.drawRect(globalX(), y, width, itemH, ctx.theme.colors.surface)
                ctx.scope.drawOutline(globalX(), y, width, itemH, ctx.theme.colors.border, 1f)

                ctx.scope.drawText(
                    labelProvider(items[i]),
                    globalX() + 6f,
                    y + height / 2f,
                    ctx.theme.colors.textPrimary,
                    1f
                )
            }
        }

        renderChildren(ctx)
    }

    override fun onEvent(event: InputEvent): Boolean {
        when (event) {

            is MouseEvent.Click -> {

                if (!isOpen) {
                    if (!contains(event.x, event.y)) return false
                    isOpen = true
                    event.consume()
                    return true
                }

                // select area click
                if (contains(event.x, event.y)) {
                    isOpen = false
                    event.consume()
                    return true
                }

                val itemH = height
                for (i in items.indices) {
                    val y = globalY() + height + i * itemH

                    if (event.x >= globalX() && event.x <= globalX() + width &&
                        event.y >= y && event.y <= y + itemH
                    ) {
                        selectedIndex = i
                        onChange?.invoke(selectedItem)
                        isOpen = false
                        event.consume()
                        return true
                    }
                }

                isOpen = false
                return true
            }
        }
        return false
    }
}